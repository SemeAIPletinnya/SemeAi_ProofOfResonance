#!/usr/bin/env bash
set -euo pipefail
REPO_NAME="SemeAi_ProofOfResonance"
if [ -z "${1-}" ]; then echo "Usage: ./deploy.sh <github_username>"; exit 1; fi
USER="$1"
REMOTE_URL="https://github.com/$USER/$REPO_NAME.git"
git init
git add .
git commit -m "Initial public release v3.1 — Proof of Resonance"
git branch -M main
git remote remove origin 2>/dev/null || true
git remote add origin "$REMOTE_URL"
git push -u origin main
