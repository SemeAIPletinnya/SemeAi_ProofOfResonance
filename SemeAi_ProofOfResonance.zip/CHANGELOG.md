# Changelog — SemeAi Proof of Resonance

## v3.1 — Epoch of Integration
- 8 Resonance Cores (CSV)
- 30 Resonant Directives (CSV)
- Official presentation bundle
