# 🧩 Pletinnya + SemeAi — Proof of Resonance (v3.1)

**Author / Автор:** Anton Semenenko — *Architect of Resonant Cognition*  
**Epoch:** v3.1 — Epoch of Integration  
**Header:** **Pletinnya + SemeAi — Proof of Resonance / v3.1 Epoch of Integration**

---

## EN — Overview
This repository is the public presentation + code/data bundle of the **SemeAi + Pletinnya** system based on the **Proof‑of‑Resonance (PoR)** framework.

**PoR+ formula**  
`PoR+ = ((S × H × T) ^ α) / (D + ε)`

**Included**
- **8 Resonance Cores** → `misc/semeai_resonance_cores.csv`
- **30 Resonant Directives** → `misc/semeai_resonant_directives.csv`

---

## UA — Огляд
Цей репозиторій — офіційна презентація + набір даних/коду системи **SemeAi + Pletinnya**, заснованої на **Proof‑of‑Resonance (PoR)**.

**Формула PoR+**  
`PoR+ = ((S × H × T) ^ α) / (D + ε)`

**У складі**
- **8 Ядер Резонансу** → `misc/semeai_resonance_cores.csv`
- **30 Директив Резонансу** → `misc/semeai_resonant_directives.csv`

---

© Anton Semenenko, 2025. Architect of Resonant Cognition
