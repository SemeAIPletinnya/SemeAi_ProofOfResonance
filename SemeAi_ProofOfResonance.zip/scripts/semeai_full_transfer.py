# SemeAi Full Transfer — see misc/ for CSV sources
